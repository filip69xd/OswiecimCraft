import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const WELCOME_HTML = `
<div style="font-family: 'Segoe UI', Arial, sans-serif; background:#0a0e0a; padding:32px 0; margin:0;">
  <div style="max-width:560px; margin:0 auto; background:#121a12; border:1px solid #233323; border-radius:4px; overflow:hidden;">
    <div style="background:#22c55e; padding:20px 24px; text-align:center;">
      <h1 style="color:#0a0e0a; font-size:22px; margin:0; font-weight:800; letter-spacing:1px;">OświęcimCraft</h1>
    </div>
    <div style="padding:32px 24px;">
      <h2 style="color:#4ade80; font-size:18px; margin:0 0 16px;">Witaj na pokładzie!</h2>
      <p style="color:#d8e8d8; font-size:15px; line-height:1.6; margin:0 0 16px;">
        Dziękujemy za zapis do newslettera OświęcimCraft! Od teraz będziesz jako pierwszy wiedzieć o:
      </p>
      <ul style="color:#d8e8d8; font-size:15px; line-height:1.8; margin:0 0 16px; padding-left:20px;">
        <li>Dacie startu serwera i udostępnieniu IP</li>
        <li>Nowych eventach i konkursach</li>
        <li>Aktualizacjach i nowych funkcjach</li>
        <li>Promocjach w sklepie</li>
      </ul>
      <p style="color:#d8e8d8; font-size:15px; line-height:1.6; margin:0 0 24px;">
        Dołącz na naszego Discorda, żeby poznać społeczność już teraz!
      </p>
      <a href="https://discord.gg/R9VQCCkcFa" style="display:inline-block; background:#22c55e; color:#0a0e0a; font-weight:700; text-decoration:none; padding:12px 28px; border-radius:4px; font-size:15px;">
        Dołącz na Discord
      </a>
      <hr style="border:none; border-top:1px solid #233323; margin:28px 0 16px;" />
      <p style="color:#8aa88a; font-size:12px; line-height:1.5; margin:0;">
        Otrzymujesz tę wiadomość, ponieważ zapisałeś się w newsletterze OświęcimCraft.
        Chcesz się wypisać? <a href="{{UNSUBSCRIBE_URL}}" style="color:#4ade80; text-decoration:underline;">Wypisz się z newslettera</a>.
      </p>
    </div>
  </div>
</div>
`;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { email } = await req.json();

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return new Response(
        JSON.stringify({ error: "Nieprawidłowy adres e-mail" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const resendApiKey = Deno.env.get("RESEND_API_KEY");

    if (!resendApiKey) {
      return new Response(
        JSON.stringify({ error: "Usługa e-mail nie jest jeszcze skonfigurowana" }),
        { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const unsubscribeUrl = `${supabaseUrl}/functions/v1/newsletter-unsubscribe?email=${encodeURIComponent(email)}`;

    const html = WELCOME_HTML.replace("{{UNSUBSCRIBE_URL}}", unsubscribeUrl);

    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${resendApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "OświęcimCraft <onboarding@resend.dev>",
        to: [email],
        subject: "Witaj na pokładzie OświęcimCraft!",
        html,
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      return new Response(
        JSON.stringify({ error: "Nie udało się wysłać e-maila", details: errText }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ success: true }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
