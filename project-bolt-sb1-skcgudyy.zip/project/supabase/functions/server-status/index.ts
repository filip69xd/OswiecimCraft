import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const SERVER_HOST = Deno.env.get("MINECRAFT_SERVER_HOST") ?? "pl21.chsrv.pl";
const SERVER_PORT = parseInt(Deno.env.get("MINECRAFT_SERVER_PORT") ?? "52195", 10);

interface MinecraftStatus {
  online: boolean;
  playersOnline: number;
  playersMax: number;
  version: string | null;
  motd: string | null;
}

async function queryMcsrvstat(host: string, port: number): Promise<MinecraftStatus | null> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 12000);

    const res = await fetch(
      `https://api.mcsrvstat.us/3/${host}:${port}`,
      { signal: controller.signal }
    );
    clearTimeout(timeout);

    if (!res.ok) return null;

    const data = await res.json();

    if (!data.online) {
      return { online: false, playersOnline: 0, playersMax: 0, version: null, motd: null };
    }

    return {
      online: true,
      playersOnline: data.players?.online ?? 0,
      playersMax: data.players?.max ?? 0,
      version: data.version ?? null,
      motd: Array.isArray(data.motd?.clean) ? data.motd.clean.join(" ") : data.motd?.clean ?? null,
    };
  } catch {
    return null;
  }
}

async function queryDirect(host: string, port: number): Promise<MinecraftStatus | null> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);

    const res = await fetch(
      `https://api.mcsrvstat.us/2/${host}:${port}`,
      { signal: controller.signal }
    );
    clearTimeout(timeout);

    if (!res.ok) return null;

    const data = await res.json();

    if (!data.online) {
      return { online: false, playersOnline: 0, playersMax: 0, version: null, motd: null };
    }

    return {
      online: true,
      playersOnline: data.players?.online ?? 0,
      playersMax: data.players?.max ?? 0,
      version: data.version ?? null,
      motd: Array.isArray(data.motd?.clean) ? data.motd.clean.join(" ") : data.motd?.clean ?? null,
    };
  } catch {
    return null;
  }
}

async function queryServer(host: string, port: number): Promise<MinecraftStatus> {
  const v3 = await queryMcsrvstat(host, port);
  if (v3) return v3;

  const v2 = await queryDirect(host, port);
  if (v2) return v2;

  return { online: false, playersOnline: 0, playersMax: 0, version: null, motd: null };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  if (req.method !== "GET") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const status = await queryServer(SERVER_HOST, SERVER_PORT);

  return new Response(JSON.stringify(status), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
