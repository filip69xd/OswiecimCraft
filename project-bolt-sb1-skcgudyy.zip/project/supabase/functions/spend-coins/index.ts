import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

type Currency = "coins" | "gems" | "diamonds";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  const authHeader = req.headers.get("Authorization");
  if (!authHeader) {
    return new Response(JSON.stringify({ error: "Brak autoryzacji" }), {
      status: 401,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const userClient = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: authHeader } } }
  );

  const { data: userData, error: userError } = await userClient.auth.getUser();
  if (userError || !userData.user) {
    return new Response(JSON.stringify({ error: "Nieprawidłowa sesja" }), {
      status: 401,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const userId = userData.user.id;

  if (req.method === "GET") {
    const { data: items, error } = await supabase
      .from("coin_shop_items")
      .select("item_key, name, description, icon, price_currency, price_amount, category")
      .order("category", { ascending: true })
      .order("price_amount", { ascending: true });

    if (error) {
      return new Response(JSON.stringify({ error: error.message }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ items: items ?? [] }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  if (req.method === "POST") {
    let body: { itemKey?: string };
    try {
      body = await req.json();
    } catch {
      return new Response(JSON.stringify({ error: "Nieprawidłowe dane" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const itemKey = body.itemKey;
    if (!itemKey) {
      return new Response(JSON.stringify({ error: "Brak identyfikatora przedmiotu" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: item, error: itemError } = await supabase
      .from("coin_shop_items")
      .select("item_key, name, price_currency, price_amount")
      .eq("item_key", itemKey)
      .maybeSingle();

    if (itemError || !item) {
      return new Response(JSON.stringify({ error: "Nie znaleziono przedmiotu" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const currency = (item.price_currency ?? "coins") as Currency;
    const price = Number(item.price_amount ?? 0);

    const { data: wallet, error: walletError } = await supabase
      .from("player_wallets")
      .select("id, coins, gems, diamonds, keys_basic, keys_gold")
      .eq("user_id", userId)
      .maybeSingle();

    if (walletError) {
      return new Response(JSON.stringify({ error: walletError.message }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!wallet) {
      return new Response(JSON.stringify({ error: "Brak portfela" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const currentBalance = Number(wallet[currency] ?? 0);
    if (currentBalance < price) {
      const currencyLabel = currency === "coins" ? "monet" : currency === "gems" ? "szmaragdów" : "diamentów";
      return new Response(JSON.stringify({
        error: `Nie masz wystarczająco ${currencyLabel}`,
        balance: currentBalance,
        required: price,
        currency,
      }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const newBalance = currentBalance - price;

    const { error: updateError } = await supabase
      .from("player_wallets")
      .update({ [currency]: newBalance, updated_at: new Date().toISOString() })
      .eq("id", wallet.id);

    if (updateError) {
      return new Response(JSON.stringify({ error: updateError.message }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    await supabase.from("coin_purchases").insert({
      user_id: userId,
      item_key: item.item_key,
      item_name: item.name,
      price_coins: currency === "coins" ? price : 0,
    });

    const balanceKey = `${currency}_remaining`;

    return new Response(JSON.stringify({
      success: true,
      item: item.name,
      [balanceKey]: newBalance,
      currency,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  return new Response(JSON.stringify({ error: "Method not allowed" }), {
    status: 405,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
