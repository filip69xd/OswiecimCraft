import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Verify caller is authenticated and is an owner
    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.replace("Bearer ", "");
    if (!token) {
      return new Response(
        JSON.stringify({ error: "Brak autoryzacji" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { data: userData, error: userErr } = await supabase.auth.getUser(token);
    if (userErr || !userData.user) {
      return new Response(
        JSON.stringify({ error: "Nieprawidłowa sesja" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const callerId = userData.user.id;

    const { data: callerRole, error: roleErr } = await supabase
      .from("admin_roles")
      .select("role")
      .eq("user_id", callerId)
      .maybeSingle();

    if (roleErr || !callerRole || callerRole.role !== "owner") {
      return new Response(
        JSON.stringify({ error: "Tylko właściciel może zarządzać adminami" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const url = new URL(req.url);
    const query = url.searchParams.get("q") || "";

    // List registered users (limited to 50), optionally filtered by email
    let dbQuery = supabase
      .from("auth_users_view")
      .select("id, email, created_at")
      .order("created_at", { ascending: false })
      .limit(50);

    if (query) {
      dbQuery = dbQuery.ilike("email", `%${query}%`);
    }

    const { data: users, error: usersErr } = await dbQuery;

    if (usersErr) {
      // Fallback: try a different approach if the view doesn't exist
      return new Response(
        JSON.stringify({ error: "Nie udało się pobrać listy użytkowników" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get current admin roles to mark which users are already admin/owner
    const { data: roles } = await supabase
      .from("admin_roles")
      .select("user_id, role");

    const roleMap = new Map<string, string>();
    for (const r of roles || []) {
      roleMap.set(r.user_id, r.role);
    }

    const result = (users || []).map((u: any) => ({
      id: u.id,
      email: u.email,
      created_at: u.created_at,
      role: roleMap.get(u.id) || null,
    }));

    return new Response(
      JSON.stringify({ users: result }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err: any) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
