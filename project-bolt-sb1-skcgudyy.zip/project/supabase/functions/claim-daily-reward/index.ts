import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

interface RewardTier {
  day: number;
  label: string;
  sublabel?: string;
  amount: number;
  icon: string;
  walletField?: "coins" | "gems" | "diamonds" | "keys_basic" | "keys_gold";
}

const REWARD_TIERS: RewardTier[] = [
  { day: 1, label: "500 monet", amount: 500, icon: "coins", walletField: "coins" },
  { day: 2, label: "10 szmaragdów", amount: 10, icon: "gem", walletField: "gems" },
  { day: 3, label: "1 klucz zwykły", amount: 1, icon: "key", walletField: "keys_basic" },
  { day: 4, label: "1000 monet", amount: 1000, icon: "coins", walletField: "coins" },
  { day: 5, label: "16 diamentów", amount: 16, icon: "diamond", walletField: "diamonds" },
  { day: 6, label: "1 klucz złoty", amount: 1, icon: "key-gold", walletField: "keys_gold" },
  { day: 7, label: "Zestaw Legendy", sublabel: "2000 monet + 20 szmaragdów + 1 klucz złoty", amount: 1, icon: "crown" },
];

const LEGENDARY_BUNDLE: Partial<RewardTier>[] = [
  { walletField: "coins", amount: 2000 },
  { walletField: "gems", amount: 20 },
  { walletField: "keys_gold", amount: 1 },
];

function todayInPoland(): string {
  const now = new Date();
  const polandTime = new Date(now.toLocaleString("en-US", { timeZone: "Europe/Warsaw" }));
  return polandTime.toISOString().split("T")[0];
}

function daysBetween(d1: string, d2: string): number {
  const date1 = new Date(d1 + "T00:00:00");
  const date2 = new Date(d2 + "T00:00:00");
  return Math.round((date2.getTime() - date1.getTime()) / (1000 * 60 * 60 * 24));
}

async function creditWallet(userId: string, reward: RewardTier): Promise<void> {
  const { data: existing } = await supabase
    .from("player_wallets")
    .select("id, coins, gems, diamonds, keys_basic, keys_gold")
    .eq("user_id", userId)
    .maybeSingle();

  const fields: { walletField: "coins" | "gems" | "diamonds" | "keys_basic" | "keys_gold"; amount: number }[] = [];
  if (reward.walletField) {
    fields.push({ walletField: reward.walletField, amount: reward.amount });
  }
  if (reward.day === 7) {
    fields.push(...LEGENDARY_BUNDLE as { walletField: "coins" | "gems" | "diamonds" | "keys_basic" | "keys_gold"; amount: number }[]);
  }

  if (fields.length === 0) return;

  if (existing) {
    const updates: Record<string, number | string> = { updated_at: new Date().toISOString() };
    for (const f of fields) {
      updates[f.walletField] = (Number(existing[f.walletField as keyof typeof existing] ?? 0)) + f.amount;
    }
    await supabase.from("player_wallets").update(updates).eq("id", existing.id);
  } else {
    const insertData: Record<string, number | string> = {
      user_id: userId,
      coins: 0,
      gems: 0,
      diamonds: 0,
      keys_basic: 0,
      keys_gold: 0,
      updated_at: new Date().toISOString(),
    };
    for (const f of fields) {
      insertData[f.walletField] = f.amount;
    }
    await supabase.from("player_wallets").insert(insertData);
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  const authHeader = req.headers.get("Authorization");
  if (!authHeader) {
    return new Response(JSON.stringify({ error: "Brak autoryzacji" }), {
      status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const userClient = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: authHeader } } }
  );

  const { data: userData, error: userError } = await userClient.auth.getUser();
  if (userError || !userData.user) {
    return new Response(JSON.stringify({ error: "Nieprawidłowa sesja" }), {
      status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const userId = userData.user.id;
  const today = todayInPoland();

  if (req.method === "GET") {
    const { data, error } = await supabase
      .from("daily_rewards")
      .select("current_streak, last_claim_date, total_claims")
      .eq("user_id", userId)
      .maybeSingle();

    if (error) {
      return new Response(JSON.stringify({ error: error.message }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const streak = data?.current_streak ?? 0;
    const lastClaimed = data?.last_claim_date ?? null;
    const totalClaimed = data?.total_claims ?? 0;

    let canClaim = true;
    let nextDay = 1;

    if (lastClaimed) {
      const diff = daysBetween(lastClaimed, today);
      if (diff === 0) {
        canClaim = false;
        nextDay = (streak % 7) + 1;
      } else if (diff === 1) {
        nextDay = (streak % 7) + 1;
      } else {
        nextDay = 1;
      }
    }

    const currentStreakDay = lastClaimed && daysBetween(lastClaimed, today) === 0
      ? ((streak - 1) % 7) + 1
      : nextDay;

    return new Response(JSON.stringify({
      streak,
      last_claimed_date: lastClaimed,
      total_claimed: totalClaimed,
      can_claim: canClaim,
      next_day: nextDay,
      current_streak_day: currentStreakDay,
      rewards: REWARD_TIERS,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  if (req.method === "POST") {
    const { data: existing, error: fetchError } = await supabase
      .from("daily_rewards")
      .select("id, current_streak, last_claim_date, total_claims")
      .eq("user_id", userId)
      .maybeSingle();

    if (fetchError) {
      return new Response(JSON.stringify({ error: fetchError.message }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (existing && existing.last_claim_date) {
      const diff = daysBetween(existing.last_claim_date, today);
      if (diff === 0) {
        return new Response(JSON.stringify({
          error: "Nagrodę na dziś już odebrano.",
          already_claimed: true,
          streak: existing.current_streak,
        }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    let newStreak: number;
    if (existing && existing.last_claim_date) {
      const diff = daysBetween(existing.last_claim_date, today);
      newStreak = diff === 1 ? existing.current_streak + 1 : 1;
    } else {
      newStreak = 1;
    }

    const rewardDay = ((newStreak - 1) % 7) + 1;
    const reward = REWARD_TIERS.find((r) => r.day === rewardDay) ?? REWARD_TIERS[0];

    if (existing) {
      const { error: updateError } = await supabase
        .from("daily_rewards")
        .update({
          current_streak: newStreak,
          last_claim_date: today,
          total_claims: (existing.total_claims ?? 0) + 1,
        })
        .eq("id", existing.id);

      if (updateError) {
        return new Response(JSON.stringify({ error: updateError.message }), {
          status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    } else {
      const { error: insertError } = await supabase
        .from("daily_rewards")
        .insert({
          user_id: userId,
          current_streak: newStreak,
          last_claim_date: today,
          total_claims: 1,
        });

      if (insertError) {
        return new Response(JSON.stringify({ error: insertError.message }), {
          status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    await creditWallet(userId, reward);

    return new Response(JSON.stringify({
      success: true,
      streak: newStreak,
      reward_day: rewardDay,
      reward,
      total_claimed: (existing?.total_claims ?? 0) + 1,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  return new Response(JSON.stringify({ error: "Method not allowed" }), {
    status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
