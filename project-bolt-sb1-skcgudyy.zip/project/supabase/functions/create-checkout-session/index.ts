import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.45.4";
import Stripe from "npm:stripe@16.10.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      {
        global: {
          headers: { Authorization: req.headers.get("Authorization")! },
        },
      },
    );

    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({ error: "Nie zalogowano" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { itemId, itemName, itemType, price } = await req.json();
    if (!itemId || !itemName || !itemType || typeof price !== "number") {
      return new Response(JSON.stringify({ error: "Brak danych" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY")!;
    const stripe = new Stripe(stripeKey);

    const origin = req.headers.get("origin") || "http://localhost:5173";

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [
        {
          quantity: 1,
          price_data: {
            currency: "pln",
            unit_amount: Math.round(price * 100),
            product_data: { name: `${itemName} — OświęcimCraft` },
          },
        },
      ],
      success_url: `${origin}/?payment=success`,
      cancel_url: `${origin}/?payment=cancelled`,
      metadata: {
        user_id: user.id,
        item_id: itemId,
        item_name: itemName,
        item_type: itemType,
        price: String(price),
      },
    });

    const serviceClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { error: insertError } = await serviceClient.from("purchases").insert({
      user_id: user.id,
      buyer_email: user.email ?? null,
      item_id: itemId,
      item_name: itemName,
      item_type: itemType,
      price: price,
      stripe_session_id: session.id,
      status: "pending",
    });

    if (insertError) {
      console.error("Insert error:", insertError.message);
    }

    return new Response(JSON.stringify({ url: session.url }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err: any) {
    console.error("Checkout error:", err);

    let message = "Nie udało się utworzyć sesji płatności";
    if (err?.type === "StripeAuthenticationError" || err?.code === "authentication_required") {
      message = "Klucz Stripe nie jest skonfigurowany. Dodaj go w ustawieniach Stripe.";
    } else if (err?.type === "StripeInvalidRequestError" || err?.code === "invalid_request_error") {
      message = "Nieprawidłowe żądanie do Stripe. Sprawdź konfigurację konta.";
    } else if (err?.type === "StripeAPIError" || err?.code === "api_error") {
      message = "Stripe chwilowo niedostępny. Spróbuj ponownie za chwilę.";
    } else if (err?.type === "StripeConnectionError" || err?.code === "api_connection_error") {
      message = "Brak połączenia ze Stripe. Sprawdź internet i spróbuj ponownie.";
    } else if (err?.message) {
      message = `Stripe: ${err.message}`;
    }

    return new Response(
      JSON.stringify({ error: message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});
