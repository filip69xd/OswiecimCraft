import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

function htmlResponse(title: string, message: string, success: boolean) {
  const color = success ? "#4ade80" : "#ef4444";
  const html = `
<!DOCTYPE html>
<html lang="pl">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>${title} — OświęcimCraft</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Segoe UI', Arial, sans-serif; background: #0a0e0a; color: #d8e8d8; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
  .card { max-width: 480px; width: 100%; background: #121a12; border: 1px solid #233323; border-radius: 4px; overflow: hidden; text-align: center; }
  .header { background: #22c55e; padding: 20px; }
  .header h1 { color: #0a0e0a; font-size: 20px; font-weight: 800; letter-spacing: 1px; }
  .body { padding: 36px 24px; }
  .body h2 { color: ${color}; font-size: 18px; margin-bottom: 14px; }
  .body p { color: #d8e8d8; font-size: 15px; line-height: 1.6; margin-bottom: 8px; }
  .body .dim { color: #8aa88a; font-size: 14px; }
  .btn { display: inline-block; margin-top: 24px; background: #22c55e; color: #0a0e0a; font-weight: 700; text-decoration: none; padding: 12px 28px; border-radius: 4px; font-size: 15px; }
  .icon { font-size: 48px; margin-bottom: 16px; }
</style>
</head>
<body>
  <div class="card">
    <div class="header"><h1>OświęcimCraft</h1></div>
    <div class="body">
      <div class="icon">${success ? "&#9989;" : "&#9888;"}</div>
      <h2>${title}</h2>
      <p>${message}</p>
      <p class="dim">${success ? "Nie otrzymasz od nas więcej wiadomości newslettera." : "Spróbuj ponownie lub skontaktuj się z nami na Discordzie."}</p>
      <a href="https://discord.gg/R9VQCCkcFa" class="btn">Dołącz na Discord</a>
    </div>
  </div>
</body>
</html>`;
  return new Response(html, {
    headers: { ...corsHeaders, "Content-Type": "text/html; charset=utf-8" },
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const email = url.searchParams.get("email");

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return htmlResponse("Błąd", "Nieprawidłowy adres e-mail.", false);
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { error } = await supabase
      .from("newsletter_signups")
      .delete()
      .eq("email", email);

    if (error) {
      console.error("Unsubscribe error:", error.message);
      return htmlResponse("Błąd", "Nie udało się wypisać z newslettera. Spróbuj ponownie później.", false);
    }

    return htmlResponse(
      "Wypisano pomyślnie",
      `Adres ${email} został usunięty z newslettera.`,
      true
    );
  } catch (err: any) {
    return htmlResponse("Błąd", "Wystąpił nieoczekiwany błąd.", false);
  }
});
