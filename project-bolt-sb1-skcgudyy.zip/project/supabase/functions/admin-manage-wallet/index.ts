import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

async function verifyAdmin(authHeader: string): Promise<{ userId: string; role: string } | null> {
  const userClient = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: authHeader } } }
  );
  const { data: userData, error } = await userClient.auth.getUser();
  if (error || !userData.user) return null;

  const { data: roleData } = await supabase
    .from("admin_roles")
    .select("role")
    .eq("user_id", userData.user.id)
    .maybeSingle();

  if (!roleData || (roleData.role !== "admin" && roleData.role !== "owner")) return null;
  return { userId: userData.user.id, role: roleData.role };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  const authHeader = req.headers.get("Authorization");
  if (!authHeader) {
    return new Response(JSON.stringify({ error: "Brak autoryzacji" }), {
      status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const admin = await verifyAdmin(authHeader);
  if (!admin) {
    return new Response(JSON.stringify({ error: "Brak uprawnień administratora" }), {
      status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  if (req.method === "GET") {
    const url = new URL(req.url);
    const searchQuery = url.searchParams.get("q") ?? "";

    let query = supabase
      .from("auth_users_view")
      .select("id, email, created_at")
      .order("created_at", { ascending: false })
      .limit(50);

    if (searchQuery.trim()) {
      query = query.ilike("email", `%${searchQuery.trim()}%`);
    }

    const { data: users, error } = await query;
    if (error) {
      return new Response(JSON.stringify({ error: error.message }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userIds = (users ?? []).map((u: any) => u.id);
    const { data: wallets } = await supabase
      .from("player_wallets")
      .select("user_id, coins, gems, diamonds, keys_basic, keys_gold")
      .in("user_id", userIds);

    const { data: roles } = await supabase
      .from("admin_roles")
      .select("user_id, role")
      .in("user_id", userIds);

    const walletMap = new Map((wallets ?? []).map((w: any) => [w.user_id, w]));
    const roleMap = new Map((roles ?? []).map((r: any) => [r.user_id, r.role]));

    const result = (users ?? []).map((u: any) => ({
      id: u.id,
      email: u.email,
      created_at: u.created_at,
      role: roleMap.get(u.id) ?? null,
      wallet: walletMap.get(u.id) ?? null,
    }));

    return new Response(JSON.stringify({ users: result }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  if (req.method === "POST") {
    let body: {
      userId?: string;
      action?: "add" | "set" | "remove";
      field?: "coins" | "gems" | "diamonds" | "keys_basic" | "keys_gold";
      amount?: number;
    };
    try {
      body = await req.json();
    } catch {
      return new Response(JSON.stringify({ error: "Nieprawidłowe dane" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { userId, action, field, amount } = body;
    if (!userId || !action || !field || amount === undefined) {
      return new Response(JSON.stringify({ error: "Brak wymaganych parametrów" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: wallet, error: walletError } = await supabase
      .from("player_wallets")
      .select("id, coins, gems, diamonds, keys_basic, keys_gold")
      .eq("user_id", userId)
      .maybeSingle();

    if (walletError) {
      return new Response(JSON.stringify({ error: walletError.message }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "remove" && !wallet) {
      return new Response(JSON.stringify({ error: "Gracz nie ma portfela" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    let newValue: number;

    if (action === "set") {
      newValue = amount;
    } else if (action === "add") {
      const current = wallet ? Number(wallet[field] ?? 0) : 0;
      newValue = current + amount;
    } else {
      const current = wallet ? Number(wallet[field] ?? 0) : 0;
      newValue = Math.max(0, current - amount);
    }

    if (wallet) {
      const { error: updateError } = await supabase
        .from("player_wallets")
        .update({ [field]: newValue, updated_at: new Date().toISOString() })
        .eq("id", wallet.id);

      if (updateError) {
        return new Response(JSON.stringify({ error: updateError.message }), {
          status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    } else {
      const { error: insertError } = await supabase
        .from("player_wallets")
        .insert({ user_id: userId, [field]: newValue, updated_at: new Date().toISOString() });

      if (insertError) {
        return new Response(JSON.stringify({ error: insertError.message }), {
          status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    return new Response(JSON.stringify({
      success: true,
      userId,
      field,
      newValue,
      action,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  if (req.method === "DELETE") {
    let body: { userId?: string; itemKey?: string };
    try {
      body = await req.json();
    } catch {
      return new Response(JSON.stringify({ error: "Nieprawidłowe dane" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { userId, itemKey } = body;
    if (!userId || !itemKey) {
      return new Response(JSON.stringify({ error: "Brak wymaganych parametrów" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { error } = await supabase
      .from("coin_purchases")
      .delete()
      .eq("user_id", userId)
      .eq("item_key", itemKey)
      .limit(1);

    if (error) {
      return new Response(JSON.stringify({ error: error.message }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ success: true, userId, itemKey }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  return new Response(JSON.stringify({ error: "Method not allowed" }), {
    status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
