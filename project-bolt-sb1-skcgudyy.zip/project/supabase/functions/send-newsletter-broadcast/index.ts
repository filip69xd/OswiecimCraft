import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

function wrapEmail(title: string, bodyHtml: string, unsubscribeUrl: string) {
  return `
<div style="font-family:'Segoe UI',Arial,sans-serif; background:#0a0e0a; padding:32px 0; margin:0;">
  <div style="max-width:560px; margin:0 auto; background:#121a12; border:1px solid #233323; border-radius:4px; overflow:hidden;">
    <div style="background:#22c55e; padding:20px 24px; text-align:center;">
      <h1 style="color:#0a0e0a; font-size:22px; margin:0; font-weight:800; letter-spacing:1px;">OświęcimCraft</h1>
    </div>
    <div style="padding:32px 24px;">
      <h2 style="color:#4ade80; font-size:18px; margin:0 0 16px;">${title}</h2>
      <div style="color:#d8e8d8; font-size:15px; line-height:1.6;">
        ${bodyHtml}
      </div>
      <a href="https://discord.gg/R9VQCCkcFa" style="display:inline-block; margin-top:24px; background:#22c55e; color:#0a0e0a; font-weight:700; text-decoration:none; padding:12px 28px; border-radius:4px; font-size:15px;">
        Dołącz na Discord
      </a>
      <hr style="border:none; border-top:1px solid #233323; margin:28px 0 16px;" />
      <p style="color:#8aa88a; font-size:12px; line-height:1.5; margin:0;">
        Otrzymujesz tę wiadomość, ponieważ zapisałeś się w newsletterze OświęcimCraft.
        Chcesz się wypisać? <a href="${unsubscribeUrl}" style="color:#4ade80; text-decoration:underline;">Wypisz się z newslettera</a>.
      </p>
    </div>
  </div>
</div>`;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.replace("Bearer ", "");
    if (!token) {
      return new Response(
        JSON.stringify({ error: "Brak autoryzacji" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const authClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: `Bearer ${token}` } } }
    );

    const { data: userData, error: userErr } = await authClient.auth.getUser();
    if (userErr || !userData.user) {
      return new Response(
        JSON.stringify({ error: "Nieprawidłowa sesja" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const callerId = userData.user.id;

    const adminClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: callerRole } = await adminClient
      .from("admin_roles")
      .select("role")
      .eq("user_id", callerId)
      .maybeSingle();

    if (!callerRole || (callerRole.role !== "owner" && callerRole.role !== "admin")) {
      return new Response(
        JSON.stringify({ error: "Brak uprawnień administratora" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { subject, body } = await req.json();

    if (!subject || !body) {
      return new Response(
        JSON.stringify({ error: "Brak tematu lub treści wiadomości" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    if (!resendApiKey) {
      return new Response(
        JSON.stringify({ error: "Usługa e-mail nie jest skonfigurowana" }),
        { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { data: subscribers, error: dbError } = await adminClient
      .from("newsletter_signups")
      .select("email");

    if (dbError) {
      return new Response(
        JSON.stringify({ error: "Błąd pobierania subskrybentów" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!subscribers || subscribers.length === 0) {
      return new Response(
        JSON.stringify({ error: "Brak zapisanych subskrybentów" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    let sent = 0;
    let failed = 0;
    const errors: string[] = [];

    for (const sub of subscribers) {
      const email = sub.email;
      const unsubscribeUrl = `${supabaseUrl}/functions/v1/newsletter-unsubscribe?email=${encodeURIComponent(email)}`;
      const html = wrapEmail(subject, body, unsubscribeUrl);

      try {
        const res = await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${resendApiKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            from: "OświęcimCraft <onboarding@resend.dev>",
            to: [email],
            subject: `${subject} — OświęcimCraft`,
            html,
          }),
        });

        if (res.ok) {
          sent++;
        } else {
          failed++;
          const errText = await res.text();
          errors.push(`${email}: ${errText}`);
        }
      } catch (err: any) {
        failed++;
        errors.push(`${email}: ${err.message}`);
      }
    }

    return new Response(
      JSON.stringify({ success: true, sent, failed, errors: errors.slice(0, 5) }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err: any) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
