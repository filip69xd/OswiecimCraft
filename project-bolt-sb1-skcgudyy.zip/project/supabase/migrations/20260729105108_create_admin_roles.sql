/*
# Create admin_roles table for owner/admin role management

1. New Tables
- `admin_roles`
  - `user_id` (uuid, primary key, references auth.users) — the user who has the role
  - `role` (text, not null) — either 'owner' or 'admin'
  - `created_at` (timestamptz, default now())
  - `created_by` (uuid, references auth.users) — who granted the role

2. Security — RLS enabled
- SELECT: any authenticated user can read the roles table (needed to check
  if the current user is owner/admin so the panel can show).
- INSERT: only existing owners can add new admins.
- DELETE: only existing owners can remove admins.
- UPDATE: only existing owners can change roles.
  No UPDATE policy is created (roles are immutable once set;
  removal + re-add is the path).

3. Notes
- The owner email sebixon2803@gmail.com is seeded as 'owner' via the
  matching auth.users id. This is a one-time bootstrap so the owner
  can then manage other admins from the panel.
*/

CREATE TABLE IF NOT EXISTS admin_roles (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('owner', 'admin')),
  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL
);

ALTER TABLE admin_roles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_admin_roles" ON admin_roles;
CREATE POLICY "select_admin_roles" ON admin_roles FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_admin_roles_owner_only" ON admin_roles;
CREATE POLICY "insert_admin_roles_owner_only" ON admin_roles FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_roles ar
      WHERE ar.user_id = auth.uid() AND ar.role = 'owner'
    )
  );

DROP POLICY IF EXISTS "delete_admin_roles_owner_only" ON admin_roles;
CREATE POLICY "delete_admin_roles_owner_only" ON admin_roles FOR DELETE
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM admin_roles ar
      WHERE ar.user_id = auth.uid() AND ar.role = 'owner'
    )
  );

-- Bootstrap the owner. Idempotent: only inserts if the row doesn't exist.
INSERT INTO admin_roles (user_id, role, created_by)
SELECT id, 'owner', id FROM auth.users
WHERE email = 'sebixon2803@gmail.com'
ON CONFLICT (user_id) DO NOTHING;
