/*
# Allow admins and owner to read all purchases

1. Security changes
- Add a SELECT policy on `purchases` so any authenticated user whose
  `admin_roles.role` is 'owner' or 'admin' can read every row (for the
  orders verification panel).
- Existing owner-scoped SELECT policy (`select_own_purchases`) stays in
  place so regular users still see only their own purchases. Both policies
  apply, so a user sees their own rows OR all rows if they are an admin.
- No INSERT/UPDATE/DELETE changes — admins do not modify orders from the
  panel (verification is read-only); the Stripe webhook still updates
  status using the service role (bypasses RLS).
*/

DROP POLICY IF EXISTS "select_all_purchases_admin" ON purchases;
CREATE POLICY "select_all_purchases_admin" ON purchases FOR SELECT
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM admin_roles ar
      WHERE ar.user_id = auth.uid()
        AND ar.role IN ('owner', 'admin')
    )
  );
