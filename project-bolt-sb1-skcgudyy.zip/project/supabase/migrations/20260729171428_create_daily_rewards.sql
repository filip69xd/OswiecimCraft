/*
# Create daily rewards system

1. New Tables
- `daily_rewards`: tracks each player's daily reward streak and claim history.
  - `id` (uuid, primary key)
  - `user_id` (uuid, not null, defaults to authenticated user, references auth.users ON DELETE CASCADE)
  - `streak` (int, current consecutive-day streak, default 0)
  - `last_claimed_date` (date, the calendar day of the last claim)
  - `total_claimed` (int, lifetime number of claims, default 0)
  - `created_at` (timestamptz)

2. Security
- Enable RLS on `daily_rewards`.
- Owner-scoped CRUD: each authenticated user can only access their own row.
- user_id defaults to auth.uid() so inserts without explicit user_id succeed.
*/

CREATE TABLE IF NOT EXISTS daily_rewards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  streak int NOT NULL DEFAULT 0,
  last_claimed_date date,
  total_claimed int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  UNIQUE (user_id)
);

ALTER TABLE daily_rewards ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_daily_rewards" ON daily_rewards;
CREATE POLICY "select_own_daily_rewards" ON daily_rewards FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_daily_rewards" ON daily_rewards;
CREATE POLICY "insert_own_daily_rewards" ON daily_rewards FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_daily_rewards" ON daily_rewards;
CREATE POLICY "update_own_daily_rewards" ON daily_rewards FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_daily_rewards" ON daily_rewards;
CREATE POLICY "delete_own_daily_rewards" ON daily_rewards FOR DELETE
  TO authenticated USING (auth.uid() = user_id);
