/*
# Create player wallet and coin shop

1. New Tables
- `player_wallets`: stores each player's in-app currency balances.
  - `id` (uuid, primary key)
  - `user_id` (uuid, not null, defaults to authenticated user, references auth.users ON DELETE CASCADE, unique)
  - `coins` (bigint, default 0) — earned from daily rewards, spent in coin shop
  - `gems` (int, default 0)
  - `diamonds` (int, default 0)
  - `keys_basic` (int, default 0)
  - `keys_gold` (int, default 0)
  - `updated_at` (timestamptz, default now())

- `coin_shop_items`: catalog of items purchasable with coins.
  - `id` (uuid, primary key)
  - `item_key` (text, unique, not null) — stable identifier used by frontend
  - `name` (text, not null)
  - `description` (text, not null)
  - `icon` (text, not null) — icon key for frontend
  - `price_coins` (int, not null) — cost in coins
  - `category` (text, not null) — 'cosmetic' | 'boost' | 'utility'
  - `created_at` (timestamptz, default now())

- `coin_purchases`: log of coin shop purchases for audit/history.
  - `id` (uuid, primary key)
  - `user_id` (uuid, not null, defaults to authenticated user, references auth.users ON DELETE CASCADE)
  - `item_key` (text, not null)
  - `item_name` (text, not null)
  - `price_coins` (int, not null)
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on all three tables.
- `player_wallets`: owner-scoped CRUD (authenticated users see/edit only their own wallet).
- `coin_shop_items`: public read (anon + authenticated) so catalog is visible to all; no insert/update/delete from frontend (service role only).
- `coin_purchases`: owner-scoped SELECT and INSERT (users can see their own history and create purchase records); no update/delete from frontend.

3. Notes
- Wallet balance changes (crediting rewards, spending coins) are performed by edge functions using the service role key, which bypasses RLS. The RLS policies protect direct frontend access so a user can only read their own wallet.
- The coin shop catalog is managed via the database; the frontend reads it but cannot modify it.
*/

CREATE TABLE IF NOT EXISTS player_wallets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  coins bigint NOT NULL DEFAULT 0,
  gems int NOT NULL DEFAULT 0,
  diamonds int NOT NULL DEFAULT 0,
  keys_basic int NOT NULL DEFAULT 0,
  keys_gold int NOT NULL DEFAULT 0,
  updated_at timestamptz DEFAULT now(),
  UNIQUE (user_id)
);

ALTER TABLE player_wallets ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_wallet" ON player_wallets;
CREATE POLICY "select_own_wallet" ON player_wallets FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_wallet" ON player_wallets;
CREATE POLICY "insert_own_wallet" ON player_wallets FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_wallet" ON player_wallets;
CREATE POLICY "update_own_wallet" ON player_wallets FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_wallet" ON player_wallets;
CREATE POLICY "delete_own_wallet" ON player_wallets FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Coin shop catalog
CREATE TABLE IF NOT EXISTS coin_shop_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  item_key text UNIQUE NOT NULL,
  name text NOT NULL,
  description text NOT NULL,
  icon text NOT NULL,
  price_coins int NOT NULL,
  category text NOT NULL DEFAULT 'utility',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE coin_shop_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_coin_shop_items" ON coin_shop_items;
CREATE POLICY "read_coin_shop_items" ON coin_shop_items FOR SELECT
  TO anon, authenticated USING (true);

-- Coin purchase history
CREATE TABLE IF NOT EXISTS coin_purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  item_key text NOT NULL,
  item_name text NOT NULL,
  price_coins int NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE coin_purchases ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_coin_purchases" ON coin_purchases;
CREATE POLICY "select_own_coin_purchases" ON coin_purchases FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_coin_purchases" ON coin_purchases;
CREATE POLICY "insert_own_coin_purchases" ON coin_purchases FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

-- Seed initial coin shop items
INSERT INTO coin_shop_items (item_key, name, description, icon, price_coins, category) VALUES
  ('color-nick', 'Kolorowy nick', 'Zmień kolor swojego nicku na czacie na jeden z dostępnych kolorów.', 'palette', 300, 'cosmetic'),
  ('particle-aura', 'Aura cząsteczek', 'Delikatna aura cząsteczek otaczająca Twoją postać w grze.', 'sparkles', 600, 'cosmetic'),
  ('hat-cosmetic', 'Kosmetyczna czapka', 'Załóż kosmetyczną czapkę — balonik, plecak lub pióro.', 'hat', 450, 'cosmetic'),
  ('fly-24h', 'Latanie 24h', 'Dostęp do komendy /fly przez 24 godziny.', 'feather', 800, 'boost'),
  ('feed-cooldown', 'Skrócenie cooldownu /feed', 'Zmniejsza czas oczekiwania między użyciami /feed o połowę.', 'utensils', 500, 'boost'),
  ('extra-plot', 'Dodatkowa działka', 'Zwiększ rozmiar swojej działki o 1 chunk.', 'map', 700, 'utility'),
  ('random-tp', 'Losowy teleport', 'Teleportuj się do losowego miejsca na mapie survival.', 'shuffle', 250, 'utility'),
  ('name-tag-pet', 'Znaczek dla peta', 'Nadaj imię swojemu petowi i otrzymaj specjalny efekt.', 'dog', 550, 'cosmetic')
ON CONFLICT (item_key) DO NOTHING;