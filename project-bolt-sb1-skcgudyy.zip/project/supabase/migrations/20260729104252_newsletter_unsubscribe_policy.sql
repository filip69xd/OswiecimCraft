/*
# Newsletter — add DELETE policy for unsubscribe

1. Changes
- `newsletter_signups` table: add DELETE policy allowing anon + authenticated to delete rows.
  This enables the unsubscribe edge function to remove a subscriber by email.
- Existing SELECT and INSERT policies remain unchanged.

2. Security
- DELETE policy scoped to `TO anon, authenticated` because unsubscribe is a public action
  (the user clicks a link in the email, no sign-in required).
- `USING (true)` is acceptable here because newsletter_signups is intentionally public
  data — any visitor may submit or unsubscribe.
*/

ALTER TABLE newsletter_signups ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_delete_signups" ON newsletter_signups;
CREATE POLICY "anon_delete_signups" ON newsletter_signups FOR DELETE
TO anon, authenticated USING (true);
