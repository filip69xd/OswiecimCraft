/*
# Create auth_users_view for edge functions

1. New Views
- `auth_users_view` — a read-only view over auth.users exposing only id, email, created_at.
  This lets the list-users edge function (which uses the service role key) retrieve
  registered user emails so the owner can search and promote them to admin.

2. Security
- The view is accessible only to the service role (bypasses RLS). Regular
  authenticated/anon users cannot query auth.users through this view because
  the underlying auth.users table has its own protections.
- No RLS policy is added — the view inherits security from the underlying table.
*/

CREATE OR REPLACE VIEW auth_users_view AS
SELECT id, email, created_at FROM auth.users;

GRANT SELECT ON auth_users_view TO service_role;
REVOKE SELECT ON auth_users_view FROM anon, authenticated;
