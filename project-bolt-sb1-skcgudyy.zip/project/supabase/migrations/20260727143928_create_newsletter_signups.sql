/*
# Create newsletter_signups table (single-tenant, no auth)

1. New Tables
- `newsletter_signups`
  - `id` (uuid, primary key)
  - `email` (text, unique, not null) — visitor's email
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on `newsletter_signups`.
- Allow anon + authenticated to INSERT (visitors sign up without logging in).
- Allow anon + authenticated to SELECT (needed to check duplicate emails / display count if used).
- No UPDATE or DELETE policies — signups are append-only.

3. Notes
- This is a no-auth public site. All policies use `TO anon, authenticated`
  because the frontend uses the anon key with no sign-in screen.
- `USING (true)` / `WITH CHECK (true)` is acceptable here because
  newsletter signups are intentionally public — any visitor may submit.
*/

CREATE TABLE IF NOT EXISTS newsletter_signups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE newsletter_signups ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_signups" ON newsletter_signups;
CREATE POLICY "anon_select_signups" ON newsletter_signups FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_signups" ON newsletter_signups;
CREATE POLICY "anon_insert_signups" ON newsletter_signups FOR INSERT
TO anon, authenticated WITH CHECK (true);
