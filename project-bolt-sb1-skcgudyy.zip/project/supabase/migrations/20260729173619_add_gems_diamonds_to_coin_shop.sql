/*
# Add currency support to coin shop (gems, diamonds)
*/

ALTER TABLE coin_shop_items ADD COLUMN IF NOT EXISTS price_currency text NOT NULL DEFAULT 'coins';
ALTER TABLE coin_shop_items ADD COLUMN IF NOT EXISTS price_amount int NOT NULL DEFAULT 0;

-- Make price_coins nullable since gem/diamond items don't use it
ALTER TABLE coin_shop_items ALTER COLUMN price_coins DROP NOT NULL;

-- Migrate existing coin items
UPDATE coin_shop_items SET price_currency = 'coins', price_amount = price_coins WHERE price_currency = 'coins' AND price_amount = 0;

-- Add gem shop items
INSERT INTO coin_shop_items (item_key, name, description, icon, price_coins, price_currency, price_amount, category) VALUES
  ('gem-crate-rare', 'Skrzynia Rzadka', 'Skrzynia z rzadkimi blokami i narzędziami. Otwórz ją na serwerze!', 'package', null, 'gems', 15, 'utility'),
  ('gem-crate-epic', 'Skrzynia Epicka', 'Skrzynia z epickimi enchantami i unikalnymi przedmiotami.', 'package', null, 'gems', 30, 'utility'),
  ('gem-fly-7d', 'Latanie 7 dni', 'Dostęp do komendy /fly przez 7 dni.', 'feather', null, 'gems', 25, 'boost'),
  ('gem-custom-warp', 'Własny warp (2 lokacje)', 'Ustaw dwa prywatne warpy, do których możesz teleportować się w każdej chwili.', 'map', null, 'gems', 40, 'utility'),
  ('gem-particle-pack', 'Pakiet efektów cząsteczek', 'Wybierz jeden z 5 efektów cząsteczek dla swojej postaci.', 'sparkles', null, 'gems', 20, 'cosmetic')
ON CONFLICT (item_key) DO NOTHING;

-- Add diamond shop items
INSERT INTO coin_shop_items (item_key, name, description, icon, price_coins, price_currency, price_amount, category) VALUES
  ('diamond-crate-legend', 'Skrzynia Legendarna', 'Najlepsza skrzynia na serwerze — unikalne przedmioty, kosmetyki i bonusy na zawsze.', 'package', null, 'diamonds', 5, 'utility'),
  ('diamond-rank-vip', 'Ranga VIP (7 dni)', 'Tymczasowa ranga VIP na 7 dni — prefix, /kit vip, większa działka.', 'crown', null, 'diamonds', 8, 'boost'),
  ('diamond-pet-custom', 'Własny pet z efektem', 'Wybierz peta i nadaj mu unikalny efekt cząsteczek.', 'dog', null, 'diamonds', 10, 'cosmetic'),
  ('diamond-glow-nick', 'Świecący nick', 'Twój nick na czacie świeci i ma animowany efekt.', 'sparkles', null, 'diamonds', 12, 'cosmetic'),
  ('diamond-extra-plot-3', '3 dodatkowe działki', 'Zwiększ limit swoich działek o 3 chunki na stałe.', 'map', null, 'diamonds', 15, 'utility')
ON CONFLICT (item_key) DO NOTHING;
