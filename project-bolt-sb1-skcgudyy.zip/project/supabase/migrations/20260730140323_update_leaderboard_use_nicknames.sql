/*
# Update leaderboard function to use nicknames instead of emails
# Drops old function first (return type changed), recreates with display_name.
*/

DROP FUNCTION IF EXISTS get_player_leaderboard(int);

CREATE FUNCTION get_player_leaderboard(limit_count int DEFAULT 10)
RETURNS TABLE (
  user_id uuid,
  display_name text,
  coins_spent bigint,
  coin_purchases_count int,
  money_spent numeric,
  shop_purchases_count int,
  last_active timestamptz
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    COALESCE(coin_data.user_id, money_data.user_id) AS user_id,
    COALESCE(
      w.nickname,
      CASE
        WHEN u.email ~ '@' THEN
          LEFT(SPLIT_PART(u.email, '@', 1), GREATEST(1, LENGTH(SPLIT_PART(u.email, '@', 1)) - 3)) ||
          '***@' || SPLIT_PART(u.email, '@', 2)
        ELSE 'gracz***'
      END,
      'gracz***'
    ) AS display_name,
    COALESCE(coin_data.coins_spent, 0)::bigint AS coins_spent,
    COALESCE(coin_data.coin_purchases_count, 0)::int AS coin_purchases_count,
    COALESCE(money_data.money_spent, 0)::numeric AS money_spent,
    COALESCE(money_data.shop_purchases_count, 0)::int AS shop_purchases_count,
    GREATEST(
      COALESCE(coin_data.last_coin_purchase, '2000-01-01'::timestamptz),
      COALESCE(money_data.last_shop_purchase, '2000-01-01'::timestamptz)
    ) AS last_active
  FROM auth_users_view u
  LEFT JOIN (
    SELECT
      user_id,
      SUM(price_coins)::bigint AS coins_spent,
      COUNT(*)::int AS coin_purchases_count,
      MAX(created_at) AS last_coin_purchase
    FROM coin_purchases
    GROUP BY user_id
  ) coin_data ON coin_data.user_id = u.id
  LEFT JOIN (
    SELECT
      user_id,
      COALESCE(SUM(price), 0)::numeric AS money_spent,
      COUNT(*)::int AS shop_purchases_count,
      MAX(created_at) AS last_shop_purchase
    FROM purchases
    WHERE status = 'paid'
    GROUP BY user_id
  ) money_data ON money_data.user_id = u.id
  LEFT JOIN player_wallets w ON w.user_id = COALESCE(coin_data.user_id, money_data.user_id)
  WHERE coin_data.user_id IS NOT NULL OR money_data.user_id IS NOT NULL
  ORDER BY coins_spent DESC, money_spent DESC
  LIMIT GREATEST(1, LEAST(limit_count, 50));
$$;

GRANT EXECUTE ON FUNCTION get_player_leaderboard(int) TO anon, authenticated;
