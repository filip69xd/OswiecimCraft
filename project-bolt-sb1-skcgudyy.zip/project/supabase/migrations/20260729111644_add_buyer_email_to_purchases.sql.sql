/*
# Add buyer_email column to purchases

1. Schema changes
- `purchases.buyer_email` (text, nullable) — stores the email of the
  purchasing user at the moment of checkout, so the admin/owner orders
  verification panel can display who bought what without needing access
  to `auth.users` (which is service-role only).

2. Notes
- Nullable so existing rows remain valid; new inserts from the
  create-checkout-session edge function will populate it.
- No RLS changes needed — the column is covered by existing policies.
*/

ALTER TABLE purchases
  ADD COLUMN IF NOT EXISTS buyer_email text;
