/*
# Create purchases table for shop orders

1. New Tables
- `purchases`
  - `id` (uuid, primary key)
  - `user_id` (uuid, not null, defaults to authenticated user, references auth.users)
  - `item_id` (text, not null) — the shop item identifier (e.g. "vip", "key-gold")
  - `item_name` (text, not null) — human-readable name (e.g. "VIP", "Klucz Złoty")
  - `item_type` (text, not null) — either "rank" or "key"
  - `price` (numeric, not null) — amount paid in PLN
  - `stripe_session_id` (text, unique) — Stripe Checkout Session ID
  - `status` (text, not null, default 'pending') — pending | paid
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on `purchases`.
- Owner-scoped CRUD: each authenticated user can only access their own purchases.
- INSERT allowed for authenticated users (owner defaulted via auth.uid()).
- SELECT only own rows.
- UPDATE only own rows (used by webhook to mark paid — note: webhook uses service role, bypasses RLS).
- DELETE only own rows.
*/

CREATE TABLE IF NOT EXISTS purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  item_id text NOT NULL,
  item_name text NOT NULL,
  item_type text NOT NULL CHECK (item_type IN ('rank', 'key')),
  price numeric(10,2) NOT NULL,
  stripe_session_id text UNIQUE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE purchases ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_purchases" ON purchases;
CREATE POLICY "select_own_purchases" ON purchases FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_purchases" ON purchases;
CREATE POLICY "insert_own_purchases" ON purchases FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_purchases" ON purchases;
CREATE POLICY "update_own_purchases" ON purchases FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_purchases" ON purchases;
CREATE POLICY "delete_own_purchases" ON purchases FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS purchases_user_id_idx ON purchases(user_id);
CREATE INDEX IF NOT EXISTS purchases_stripe_session_idx ON purchases(stripe_session_id);
