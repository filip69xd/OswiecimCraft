/*
# Create news table

1. New Tables
- `news`
  - `id` (uuid, primary key)
  - `title` (text, not null) — news headline
  - `excerpt` (text, not null) — short summary shown on cards
  - `content` (text, not null) — full article body
  - `tag` (text, not null) — category label (e.g. "Aktualizacja", "Rekrutacja", "Sklep")
  - `created_at` (timestamptz, default now()) — publication date
  - `author_email` (text) — who created the news entry

2. Security — RLS enabled
- SELECT: public (anon + authenticated) — anyone visiting the site can read news.
- INSERT: only owner or admin (checked via admin_roles table).
- DELETE: only owner or admin.
- UPDATE: only owner or admin.

3. Notes
- Seeds the three existing hardcoded news entries so the site doesn't go empty.
*/

CREATE TABLE IF NOT EXISTS news (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  excerpt text NOT NULL,
  content text NOT NULL,
  tag text NOT NULL DEFAULT 'Aktualizacja',
  created_at timestamptz DEFAULT now(),
  author_email text
);

ALTER TABLE news ENABLE ROW LEVEL SECURITY;

-- Anyone can read news (public)
DROP POLICY IF EXISTS "select_news_public" ON news;
CREATE POLICY "select_news_public" ON news FOR SELECT
  TO anon, authenticated USING (true);

-- Only owner or admin can insert
DROP POLICY IF EXISTS "insert_news_admin" ON news;
CREATE POLICY "insert_news_admin" ON news FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_roles
      WHERE admin_roles.user_id = auth.uid()
      AND admin_roles.role IN ('owner', 'admin')
    )
  );

-- Only owner or admin can delete
DROP POLICY IF EXISTS "delete_news_admin" ON news;
CREATE POLICY "delete_news_admin" ON news FOR DELETE
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM admin_roles
      WHERE admin_roles.user_id = auth.uid()
      AND admin_roles.role IN ('owner', 'admin')
    )
  );

-- Only owner or admin can update
DROP POLICY IF EXISTS "update_news_admin" ON news;
CREATE POLICY "update_news_admin" ON news FOR UPDATE
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM admin_roles
      WHERE admin_roles.user_id = auth.uid()
      AND admin_roles.role IN ('owner', 'admin')
    )
  ) WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_roles
      WHERE admin_roles.user_id = auth.uid()
      AND admin_roles.role IN ('owner', 'admin')
    )
  );

-- Seed existing news entries
INSERT INTO news (title, excerpt, content, tag, created_at)
VALUES
  ('Prace nad serwerem trwają — szukamy hostingu!',
   'Konfiguracja pluginów i mapy idzie zgodnie z planem. Aktualnie szukamy odpowiedniego hostingu, pod którym serwer będzie działał stabilnie i bez lagów.',
   'Prace nad OświęcimCraft idą pełną parą! Mapa spawnu jest już w budowie, pluginy ekonomiczne i system działek są skonfigurowane i przetestowane. Brakuje nam jednak jednej kluczowej rzeczy — hostingu. Aktualnie szukamy serwera, który udźwignie naszą społeczność i zapewni stabilne działanie bez lagów. Gdy tylko wybierzemy hosting i uruchomimy serwer, IP pojawi się na stronie, a wszyscy zapisani na newsletter dostaną powiadomienie. Dołącz na Discorda, żeby być na bieżąco!',
   'Aktualizacja', '2026-07-27T00:00:00Z'),
  ('Rekrutacja do zespołu otwarta',
   'Szukamy moderatorów oraz builderów do naszego zespołu. Aplikacje przyjmujemy na naszym Discordzie.',
   'Szukamy zaangażowanych osób do naszego zespołu! Poszukujemy moderatorów, którzy zadbają o porządek i dobrą atmosferę na serwerze, oraz builderów, którzy pomogą nam tworzyć spawn i eventowe budowle. Wymagamy pełnoletności, komunikatywności i chęci do działania. Aplikacje przyjmujemy wyłącznie na naszym Discordzie w dedykowanym kanale. Dołącz już dziś i zbuduj z nami coś wielkiego!',
   'Rekrutacja', '2026-07-20T00:00:00Z'),
  ('System rang i nagród już dostępny',
   'Otwieramy sklep z rangami, kluczami i pakietami. Wspieraj serwer i odbierz wyjątkowe korzyści w grze.',
   'Otwieramy oficjalny sklep OświęcimCraft! Znajdziesz w nim rangi (VIP, SVIP, MVP), klucze do skrzyń z nagrodami oraz różne pakiety. Wszystkie zakupy są dobrowolne i służą utrzymaniu oraz rozwojowi serwera — hosting, pluginy i nagrody dla graczy kosztują. W zamian otrzymujesz wyjątkowe korzyści w grze: większe działki, kity, komendy i więcej. Dziękujemy za każde wsparcie!',
   'Sklep', '2026-07-15T00:00:00Z')
ON CONFLICT DO NOTHING;
